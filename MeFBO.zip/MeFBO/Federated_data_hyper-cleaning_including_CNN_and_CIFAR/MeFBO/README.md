# Federated Bilevel Learning Algorithm (Pytorch)
MeFBO for Federated Data Hyper-cleaning


# Requirements
python>=3.6  

pytorch>=0.4

## model
mlp, cnn

## dataset 
fmnist, cifar


## Usage
```
python mefbo.py --inner_ep 1 --eta 0.2,0.2,0.1 --gamma 0.15,0.15,0.1 --seed 42 --iid --gpu 0
```
