# Customize Run


A simple run example is as following
> python fednest_dhc.py --iid --epochs 50 --gpu 0 

By control the augments, there can be more configuration. In the paper, the authors mainly discuss four varients of FedNest. Here we provide the corresponding parameters to run each of them:

![alt 4 main algorithms appears in the paper.](figs/fig_algo.png)

- FedNest
    > --hvp_method global --optim svrg
- LFedNest
    > --hvp_method seperate --optim sgd
- FedNest<sub>SGD</sub>
    > --hvp_method global --optim sgd
- LFedNest<sub>SVRG</sub>
    > --hvp_method seperate --optim svrg

