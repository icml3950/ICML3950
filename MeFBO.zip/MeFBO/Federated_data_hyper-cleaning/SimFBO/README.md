# Federated Bilevel Learning Algorithm (Pytorch)
MeFBO for Federated Data Hyper-cleaning


# Requirements
python>=3.6  

pytorch>=0.4

## model
mlp

## dataset 
mnist


## Usage
```
python simfbo_dhc.py  --seed 42 --iid --gpu 0
```
