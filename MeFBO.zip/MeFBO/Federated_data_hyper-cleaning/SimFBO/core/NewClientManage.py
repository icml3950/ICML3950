import copy
from cv2 import log
import numpy as np

import torch
from torch.optim import SGD

from core.function import gather_flat_hyper_params ,get_trainable_hyper_params 
from utils.Fed import FedAvg, FedAvgGradient, FedAvgP
from utils.Fed import *
from core.function import *
from core.SGDClient import SGDClient
from core.SVRGClient import SVRGClient
from core.NewThetaClient import NewThetaClient
from core.Client import Client
from core.ClientManage import ClientManage

class NewClientManage(ClientManage):
    def __init__(self, args, net_glob, client_idx, dataset, dict_users, hyper_params, param, v) -> None:
        super().__init__(args, net_glob, client_idx, dataset, dict_users)
        
        self.client_idx = client_idx
        self.args = args
        self.dataset = dataset
        self.dict_users = dict_users
        self.net_glob = copy.deepcopy(net_glob)

        self.param = [x.clone().detach() for x in param]
        self.v = [x.clone().detach() for x in v]
        #self.hyper_param = {
        #    'dy': hyper_param['dy'].clone().detach(),  
        #    'ly': hyper_param['ly'].clone().detach(),
        #    'wy': hyper_param['wy'].clone().detach()  
        #}
        #self.hyper_param['dy'].requires_grad_()
        #self.hyper_param['ly'].requires_grad_()
        self.hyper_params = hyper_params
        self.param_old = [x.clone().detach() for x in param]
        self.v_old = [x.clone().detach() for x in v]
        #self.hyper_param_old = {
        #    'dy': hyper_param['dy'].clone().detach(),  
        #    'ly': hyper_param['ly'].clone().detach(),
        #    'wy': hyper_param['wy'].clone().detach()  
        #}
        #self.hyper_param_old['dy'].requires_grad_()
        #self.hyper_param_old['ly'].requires_grad_()

        #self.hyper_optimizer= SGD([self.hyper_param[k] for k in self.hyper_param], lr=alpha)
     


    def client_job(self, eta):
        h_y = []
        h_v = []
        h_x = []
        client_locals = []
        min_eigenvalue_grads = []
        inverse_spectral_norm_grads = []
        inverse_spectral_norm_grad1s = []
        condition_number_grad1s = []
        for idx in self.client_idx:
            client = SVRGClient(self.args, idx, self.net_glob, self.dataset, self.dict_users, self.param,
                                self.hyper_params[idx], self.v)
            hyper_param = self.hyper_params[idx]
            # update y
            for k in range(self.args.inner_ep):
                # update y
                inner_grad = client.grad_d_in_d_y()
                #min_eigenvalue_grads.append(min_eigenvalue_grad)
                #inverse_spectral_norm_grads.append(inverse_spectral_norm_grad)
                #inverse_spectral_norm_grad1s.append(inverse_spectral_norm_grad1)
                #condition_number_grad1s.append(condition_number_grad1)
                count = 0
                for param in client.net.parameters():
                    param.data = param.data - eta[0] * inner_grad[count]
                    count += 1
            
            # update v
            v_grad = client.grad_v_R()
            for i in range(len(self.param)):
                client.v[i] = client.v[i] - eta[1] * v_grad[i]

            # update x
            x_update = client.grad_f_bar()
            count = 0 

                      
            #self.hyper_param['dy'] = self.hyper_param['dy'] - eta[2] * x_update[0] 
            #self.hyper_param['ly'] = self.hyper_param['ly'] - eta[2] * x_update[1]
            for count in range(len(hyper_param)):     
                    hyper_param.detach()[count] = hyper_param.detach()[count] - eta[2] * x_update[count]
                
            h_yi = []
            h_vi = []
            #h_xi = []


            count = 0
            for params in client.net.parameters():
                h_yi.append((-params.data + self.param_old[count]) / (eta[0] * self.args.inner_ep)) 
                h_vi.append((-client.v[count] + self.v_old[count]) /(eta[1] * self.args.inner_ep))
                count += 1

            #count = 0
            #for params_name, params in self.hyper_param.items():
            #    h_xi.append((-params.data + self.hyper_param_old[params_name]) / (eta[2] * self.args.inner_ep))    
            #    count += 1
            
            current_memory = torch.cuda.max_memory_allocated(3)/ (1024**2)
            print('===================================current_memor:',current_memory)    
         
            client_locals.append(client)
            #h_x.append(h_xi)
            h_y.append(h_yi)
            h_v.append(h_vi)
            
        #max_value = max(abs(b) / abs(a) for a, b in zip(inverse_spectral_norm_grads, inverse_spectral_norm_grad1s))
        return h_y, h_v #h_x,\
            


    
