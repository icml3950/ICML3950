# Federated-Bilevel-Learning
Federated Bilevel Learning Algorithm (Pytorch) : MeFBO

# Requirements
pytorch >= 1.6

torchvision >= 0.9.0

## model
MLP

## dataset 
MNIST

## Usage
```
python SimFBO.py --inner_ep 1  --seed 42 --iid
```
- `--inner_ep`: Number of inner loop epochs.
- `--eta`: Learning rates for the client (comma-separated).
- `--gamma`: Learning rates for the server (comma-separated).
- `--seed`: Random seed for reproducibility.
